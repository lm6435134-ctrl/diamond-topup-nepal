import { NextResponse } from 'next/server';
import { requireUser, serverDb, FieldValue } from '@/lib/server';
export const runtime='nodejs';
export async function POST(req:Request) {
  try {
    const user=await requireUser(req);
    const {subscription}=await req.json();
    if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth)
      return NextResponse.json({error:'Invalid browser push subscription.'},{status:400});
    const db=serverDb();
    const old=await db.collection('pushSubscriptions').where('endpoint','==',subscription.endpoint).limit(1).get();
    if (!old.empty) await old.docs[0].ref.set({userId:user.uid,subscription,endpoint:subscription.endpoint,updatedAt:FieldValue.serverTimestamp()},{merge:true});
    else await db.collection('pushSubscriptions').add({userId:user.uid,subscription,endpoint:subscription.endpoint,createdAt:FieldValue.serverTimestamp()});
    return NextResponse.json({ok:true});
  } catch(e:any) { return NextResponse.json({error:e.message || 'Could not enable push.'},{status:400}); }
}
