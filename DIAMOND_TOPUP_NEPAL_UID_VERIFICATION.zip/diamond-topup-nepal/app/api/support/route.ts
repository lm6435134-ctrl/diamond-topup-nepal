import { NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { FieldValue, notifyAdmin, requireUser, serverDb } from '@/lib/server';
export const runtime = 'nodejs';

const system = `You are Diamond Topup Nepal's 24/7 customer support assistant.
Help customers with Free Fire Bangladesh top-up packages, order tracking, payment reference submission, wallet requests and account navigation.
Never ask for passwords, OTPs, full card details or secret keys. Never claim a payment is verified or diamonds are delivered.
Payment transaction IDs are references only and require manual admin verification. UID verification and automatic diamond delivery are not available unless an admin confirms otherwise.
If the issue is account-specific, payment disputes, missing top-ups, refunds, or you are uncertain, clearly offer human admin support. Be concise, polite and reply in the customer's language (Nepali or English).`;

export async function POST(req: Request) {
  try {
    const user = await requireUser(req);
    const body = await req.json();
    const message = String(body.message || '').trim().slice(0, 2000);
    const history = Array.isArray(body.history) ? body.history.slice(-8).map((m:any)=>({
      role: m.role === 'model' ? 'model' : 'user',
      parts: [{text:String(m.text || '').slice(0,1500)}]
    })) : [];
    if (!message) return NextResponse.json({error:'Please enter a message.'},{status:400});
    if (!process.env.GEMINI_API_KEY) return NextResponse.json({error:'AI support is not configured yet. Please contact Admin Support.'},{status:503});
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({model:process.env.GEMINI_MODEL || 'gemini-2.0-flash',systemInstruction:system});
    const chat = model.startChat({history});
    const result = await chat.sendMessage(message);
    const reply = result.response.text();
    const needsHuman = /\b(admin|human|agent|support team|escalat|refund|missing top.?up|not received|payment dispute)\b/i.test(message)
      || /\b(contact admin|admin support|human support)\b/i.test(reply);
    let ticketId: string | undefined;
    if (needsHuman) {
      const db=serverDb();
      const ref=await db.collection('supportTickets').add({
        userId:user.uid, customerEmail:user.email || '', message, status:'Open',
        source:'Gemini AI escalation', createdAt:FieldValue.serverTimestamp()
      });
      ticketId=ref.id;
      await notifyAdmin('Customer needs support', `${user.email || user.uid}: ${message.slice(0,240)}`, {ticketId});
    }
    return NextResponse.json({reply,escalated:!!ticketId,ticketId});
  } catch(e:any) {
    return NextResponse.json({error:e.message || 'Support is temporarily unavailable.'},{status:400});
  }
}
