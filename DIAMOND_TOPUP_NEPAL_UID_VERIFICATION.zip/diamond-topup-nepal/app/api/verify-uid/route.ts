import { NextResponse } from 'next/server';
import { requireUser } from '@/lib/server';
export const runtime = 'nodejs';

export async function POST(req: Request) {
  try {
    await requireUser(req);
    const { uid, region = 'BD' } = await req.json();
    const playerUid = String(uid || '').trim();
    const playerRegion = String(region || 'BD').trim().toUpperCase();
    const allowedRegions = ['BD','IND','BR','US','SAC','NA','TH','ID','SG','PK'];
    if (!/^\d{6,15}$/.test(playerUid))
      return NextResponse.json({ error: 'Enter a valid numeric Free Fire UID.' }, { status: 400 });
    if (!allowedRegions.includes(playerRegion))
      return NextResponse.json({ error: 'Unsupported Free Fire region.' }, { status: 400 });
    const apiKey = process.env.UID_API_KEY;
    if (!apiKey) return NextResponse.json({ error: 'UID verification is not configured by Admin.' }, { status: 503 });

    const url = new URL('https://api.gameskinbo.com/ff-info/get');
    url.searchParams.set('uid', playerUid);
    url.searchParams.set('region', playerRegion);
    const upstream = await fetch(url.toString(), {
      method: 'GET',
      headers: { 'x-api-key': apiKey },
      cache: 'no-store',
      signal: AbortSignal.timeout(15000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const status = upstream.status === 402 ? 404 : upstream.status;
      const error = upstream.status === 401 ? 'UID API key was rejected. Please contact Admin.'
        : upstream.status === 429 ? 'UID API limit/rate limit reached. Please try again later.'
        : upstream.status === 402 ? 'Invalid UID or player could not be found.'
        : 'UID verification service is temporarily unavailable.';
      return NextResponse.json({ error }, { status });
    }
    const account = data?.AccountInfo;
    const returnedUid = String(data?.SocialInfo?.accountId || playerUid);
    if (!account?.AccountName || returnedUid !== playerUid)
      return NextResponse.json({ error: 'Player UID could not be verified. Check the UID and region.' }, { status: 404 });
    return NextResponse.json({
      verified: true,
      uid: playerUid,
      playerName: String(account.AccountName),
      region: String(account.AccountRegion || playerRegion).toUpperCase(),
      level: Number(account.AccountLevel || 0)
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.name === 'TimeoutError' ? 'UID verification timed out. Try again.' : (e.message || 'Could not verify UID.') }, { status: 400 });
  }
}
