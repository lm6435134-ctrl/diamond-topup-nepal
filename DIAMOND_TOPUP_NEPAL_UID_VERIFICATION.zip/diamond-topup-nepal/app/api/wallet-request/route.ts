import { NextResponse } from 'next/server';
import { FieldValue, notify, requireUser, sendEmail, serverDb } from '@/lib/server';
export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    const user = await requireUser(req);
    const body = await req.json();
    const amount = Number(body.amount);
    const transactionId = String(body.transactionId || '').trim();
    if (!Number.isInteger(amount) || amount < 10 || amount > 10000) return NextResponse.json({error:'Amount must be Rs. 10–10,000.'},{status:400});
    if (!transactionId) return NextResponse.json({error:'Transaction ID is required.'},{status:400});
    const db = serverDb(), profile = await db.collection('users').doc(user.uid).get();
    const customerName = profile.data()?.displayName || user.name || 'Customer';
    const ref = db.collection('walletRequests').doc();
    await ref.set({userId:user.uid,customerName,customerEmail:user.email || '',amountNpr:amount,transactionId,paymentMethod:'eSewa QR',status:'Pending',createdAt:FieldValue.serverTimestamp()});
    await notify(user.uid,'Wallet request received',`Your Rs. ${amount} wallet load request is pending verification.`,{requestId:ref.id,transactionId});
    if (process.env.ADMIN_EMAIL) await sendEmail(process.env.ADMIN_EMAIL,`Wallet load request ${ref.id}`,`<h2>New wallet load request</h2><p>Customer: ${customerName}</p><p>Email: ${user.email || ''}</p><p>Amount: Rs. ${amount}</p><p>Transaction ID: ${transactionId}</p><p>Request ID: ${ref.id}</p><p>Status: Pending</p>`);
    if (user.email) await sendEmail(user.email,'Wallet load request received',`<p>Your Rs. ${amount} wallet load request is pending verification.</p><p>Transaction ID: ${transactionId}</p><p>Request ID: ${ref.id}</p>`);
    return NextResponse.json({ok:true,requestId:ref.id});
  } catch(e:any) { return NextResponse.json({error:e.message || 'Could not submit wallet request.'},{status:400}); }
}
