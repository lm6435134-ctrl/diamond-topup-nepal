import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title:'Diamond Topup Nepal', description:'Free Fire Bangladesh diamond top-up store' };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}