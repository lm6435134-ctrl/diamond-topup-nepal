import { NextResponse } from 'next/server';
import { FieldValue, notify, requireUser, sendEmail, serverDb } from '@/lib/server';
export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    const user = await requireUser(req);
    const body = await req.json();
    const uid = String(body.uid || '').trim();
    const packageId = String(body.packageId || '');
    const paymentMethod = body.paymentMethod === 'Wallet' ? 'Wallet' : 'eSewa QR';
    const transactionId = String(body.transactionId || '').trim();
    if (!uid || !/^\d{6,15}$/.test(uid)) return NextResponse.json({error:'Enter a valid numeric Player UID.'},{status:400});
    if (paymentMethod === 'eSewa QR' && !transactionId) return NextResponse.json({error:'Transaction ID is required.'},{status:400});
    const db = serverDb();
    const pkg = await db.collection('packages').doc(packageId).get();
    if (!pkg.exists || pkg.data()?.active !== true) return NextResponse.json({error:'Package not found.'},{status:400});
    const p = pkg.data()!;
    const profile = await db.collection('users').doc(user.uid).get();
    const customerName = profile.data()?.displayName || user.name || 'Customer';
    const orderRef = db.collection('orders').doc();
    const orderData:any = {userId:user.uid,customerName,customerEmail:user.email || '',uid,packageId,packageName:p.name,amountNpr:p.priceNpr,transactionId:transactionId || 'Paid from wallet',paymentMethod,paymentStatus:paymentMethod==='Wallet'?'Paid from wallet':'Pending verification',status:paymentMethod==='Wallet'?'Processing':'Pending',createdAt:FieldValue.serverTimestamp()};
    if (paymentMethod === 'Wallet') {
      await db.runTransaction(async tx=>{
        const userRef=db.collection('users').doc(user.uid);
        const fresh=await tx.get(userRef);
        const balance=Number(fresh.data()?.walletBalance || 0);
        if (balance < Number(p.priceNpr)) throw new Error('Insufficient wallet balance.');
        tx.update(userRef,{walletBalance:FieldValue.increment(-Number(p.priceNpr))});
        tx.set(db.collection('walletTransactions').doc(),{userId:user.uid,type:'Debit',amountNpr:Number(p.priceNpr),orderId:orderRef.id,createdAt:FieldValue.serverTimestamp()});
        tx.set(orderRef,orderData);
      });
    } else {
      await orderRef.set(orderData);
    }
    await notify(user.uid,'Order received',paymentMethod==='Wallet'?`Your ${p.name} order is paid from wallet and is processing.`:`Your ${p.name} order is waiting for payment verification.`,{orderId:orderRef.id,transactionId:orderData.transactionId});
    const adminEmail = process.env.ADMIN_EMAIL;
    if (adminEmail) await sendEmail(adminEmail,`New order ${orderRef.id}`,`<h2>New Diamond Topup Nepal order</h2><p>Order ID: ${orderRef.id}</p><p>Customer: ${customerName}</p><p>Email: ${user.email || ''}</p><p>UID: ${uid}</p><p>Package: ${p.name}</p><p>Amount: Rs. ${p.priceNpr}</p><p>Payment: ${paymentMethod}</p><p>Transaction ID: ${orderData.transactionId}</p><p>Status: ${orderData.status}</p>`);
    if (user.email) await sendEmail(user.email,`Order received: ${orderRef.id}`,`<h2>We received your order</h2><p>Order ID: ${orderRef.id}</p><p>Package: ${p.name}</p><p>Player UID: ${uid}</p><p>Transaction ID: ${orderData.transactionId}</p><p>Payment status: ${orderData.paymentStatus}</p>`);
    return NextResponse.json({ok:true,orderId:orderRef.id});
  } catch(e:any) { return NextResponse.json({error:e.message || 'Could not submit order.'},{status:400}); }
}
